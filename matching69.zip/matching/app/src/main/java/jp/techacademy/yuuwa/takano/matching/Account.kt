package jp.techacademy.yuuwa.takano.matching

import java.io.Serializable
import java.util.ArrayList

class Account(var accountAddress:String, var accountName:String, var accountGenre:String, var accountSkill:String/*,var bytes:ByteArray*/): Serializable {

//    val imageBytes: ByteArray
//
//    init {
//        imageBytes = bytes.clone()
//    }

}