package jp.techacademy.yuuwa.takano.matching

const val AccountPATH = "account"

const val FavoritePATH = "favsenduser"